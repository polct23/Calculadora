package com.example.calculadora;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    int num1;
    int num2;
    String actual;
    String operacion;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void cero(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "0";
        txtView.setText(actual);
    }
    public void uno(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "1";
        txtView.setText(actual);

    }
    public void dos(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "2";
        txtView.setText(actual);

    }
    public void tres(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "3";
        txtView.setText(actual);

    }
    public void cuatro(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "4";
        txtView.setText(actual);

    }
    public void cinco(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "5";
        txtView.setText(actual);

    }
    public void seis(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "6";
        txtView.setText(actual);

    }
    public void siete(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "7";
        txtView.setText(actual);

    }
    public void ocho(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "8";
        txtView.setText(actual);

    }
    public void nueve(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        actual = actual + "9";
        txtView.setText(actual);

    }
    public void mas(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        if(num1 != -1){
            int num3 = Integer.parseInt(actual);
            num1 = num1 + num3;
        }
        else{
            num1 = Integer.parseInt(actual);
        }
        operacion = "+";
        txtView.setText("");

    }
    public void menos(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        if(num1 != -1){
            int num3 = Integer.parseInt(actual);
            num1 = num1 - num3;
        }
        else{
            num1 = Integer.parseInt(actual);
        }
        operacion = "-";
        txtView.setText("");

    }
    public void por(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        if(num1 != -1){
            int num3 = Integer.parseInt(actual);
            num1 = num1 * num3;
        }
        else{
            num1 = Integer.parseInt(actual);
        }
        operacion = "*";
        txtView.setText("");

    }
    public void division(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        if(num1 != -1){
            int num3 = Integer.parseInt(actual);
            num1 = num1 / num3;
        }
        else{
            num1 = Integer.parseInt(actual);
        }

        txtView.setText("");
        operacion = "/";
    }
    public void igual(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        num2 = Integer.parseInt(actual);
        String num3 = "";
        if(operacion == "+")
        {
            num3 = Integer.toString(num1 + num2) ;

        }
        else if (operacion == "-") {

            num3 = Integer.toString(num1 - num2) ;

        }
        else if (operacion == "*") {

            num3 = Integer.toString(num1 * num2) ;

        }
        else if (operacion == "/") {

            num3 = Integer.toString(num1 / num2) ;

        }


        txtView.setText(num3);
        num1 = -1;

    }
    public void clear(View view){
        operacion = "";
        num1 = -1;
        TextView txtView = (TextView)findViewById(R.id.textView);
        txtView.setText("");

    }

    public void seno(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        num1 = Integer.parseInt(actual);
        double b;
        Switch switchE = (Switch) findViewById(R.id.switch1);
        if(switchE.isChecked())
        {
            b = Math.sin(num1);
        }
        else{
            b = Math.sin(Math.toRadians(num1));
        }
        txtView.setText(String.valueOf(b));

    }
    public void coseno(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        num1 = Integer.parseInt(actual);
        double b;
        Switch switchE = (Switch) findViewById(R.id.switch1);

        if(switchE.isChecked())
        {
            b = Math.cos(num1);
        }
        else{
            b = Math.cos(Math.toRadians(num1));
        }
        txtView.setText(String.valueOf(b));

    }
    public void tangente(View view){
        TextView txtView = (TextView)findViewById(R.id.textView);
        actual = (String) txtView.getText();
        num1 = Integer.parseInt(actual);
        double b;
        Switch switchE = (Switch) findViewById(R.id.switch1);
        if(switchE.isChecked())
        {
            b = Math.tan(num1);
        }
        else{
            b = Math.tan(Math.toRadians(num1));
        }
        txtView.setText(String.valueOf(b));

    }

}